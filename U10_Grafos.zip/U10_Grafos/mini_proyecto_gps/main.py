# main.py
# Sistema de Navegacion GPS (menu en consola)
# Para correrlo: python main.py

from mapa_gps import MapaGPS, formatear_tiempo


def cargar_datos(mapa):
    # Datos de ejemplo (los tiempos son aproximados)
    datos = [
        ("Managua", "Masaya", 30),
        ("Managua", "Granada", 50),
        ("Masaya", "Granada", 25),
        ("Granada", "Rivas", 70),
        ("Managua", "Rivas", 100),
        ("Managua", "León", 75),
        ("León", "Chinandega", 40),
        ("Managua", "Matagalpa", 120),
        ("Matagalpa", "Jinotega", 45),
        ("Matagalpa", "Estelí", 80),
        ("Managua", "Estelí", 150),
        ("Managua", "Juigalpa", 105),
    ]
    for origen, destino, minutos in datos:
        mapa.agregar_ruta(origen, destino, minutos)


def mostrar_menu():
    print()
    print("Sistema de Navegacion GPS")
    print("1. Ver ciudades")
    print("2. Ver rutas")
    print("3. Agregar una ruta nueva")
    print("4. Consultar la ruta mas rapida")
    print("5. Salir")


def ver_ciudades(mapa):
    ciudades = mapa.ver_ciudades()
    print()
    print("Ciudades (" + str(len(ciudades)) + "):")
    numero = 1
    for ciudad in ciudades:
        print("  " + str(numero) + ". " + ciudad)
        numero = numero + 1


def ver_rutas(mapa):
    rutas = mapa.ver_rutas()
    print()
    if len(rutas) == 0:
        print("Todavia no hay rutas.")
        return
    print("Rutas (" + str(len(rutas)) + "):")
    for a, b, minutos in rutas:
        print("  " + a + " <-> " + b + ": " + formatear_tiempo(minutos))


def agregar_ruta(mapa):
    print()
    print("Agregar ruta nueva")
    print("(si una ciudad no existe se crea sola)")
    origen = input("Ciudad de origen: ")
    destino = input("Ciudad de destino: ")
    texto = input("Tiempo en minutos: ")

    # reviso que el tiempo sea un numero entero
    try:
        minutos = int(texto.strip())
    except ValueError:
        print("Error: el tiempo tiene que ser un numero entero (ejemplo: 45)")
        return

    try:
        anterior = mapa.agregar_ruta(origen, destino, minutos)
    except ValueError as error:
        print("Error:", error)
        return

    a = mapa.buscar_ciudad(origen)
    b = mapa.buscar_ciudad(destino)
    if anterior is None:
        print("Ruta agregada: " + a + " <-> " + b + " (" + formatear_tiempo(minutos) + ")")
    else:
        print("Esa ruta ya existia, se actualizo el tiempo de " +
              formatear_tiempo(anterior) + " a " + formatear_tiempo(minutos))


def consultar_ruta(mapa):
    print()
    print("Consultar ruta mas rapida")
    print("Ciudades: " + ", ".join(mapa.ver_ciudades()))
    origen = input("Ciudad de origen: ")
    destino = input("Ciudad de destino: ")

    try:
        minutos, camino = mapa.ruta_mas_rapida(origen, destino)
    except ValueError as error:
        print("Error:", error)
        return

    if minutos is None:
        a = mapa.buscar_ciudad(origen)
        b = mapa.buscar_ciudad(destino)
        print("No hay ninguna ruta entre " + a + " y " + b + ".")
        return

    if len(camino) == 1:
        print("Ya estas en " + camino[0] + " (0 min).")
        return

    print()
    print("Ruta mas rapida: " + " -> ".join(camino))
    for i in range(len(camino) - 1):
        a = camino[i]
        b = camino[i + 1]
        print("  " + a + " -> " + b + ": " + formatear_tiempo(mapa.tiempo_entre(a, b)))
    print("Tiempo total: " + formatear_tiempo(minutos))


def main():
    mapa = MapaGPS()
    cargar_datos(mapa)

    while True:
        mostrar_menu()
        try:
            opcion = input("Elige una opcion: ").strip()

            if opcion == "1":
                ver_ciudades(mapa)
            elif opcion == "2":
                ver_rutas(mapa)
            elif opcion == "3":
                agregar_ruta(mapa)
            elif opcion == "4":
                consultar_ruta(mapa)
            elif opcion == "5":
                print("Buen viaje!")
                break
            else:
                print("Opcion no valida, escribe un numero del 1 al 5.")

        except (EOFError, KeyboardInterrupt):
            # por si se cierra la entrada o se presiona Ctrl+C
            print()
            print("Saliendo del programa...")
            break
        except Exception as error:
            # para que el programa no se cierre por un error inesperado
            print("Ocurrio un error inesperado:", error)


main()
