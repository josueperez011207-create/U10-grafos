# mapa_gps.py
# Aqui esta el grafo del GPS: cada ciudad es un nodo y cada autopista
# es una arista con el tiempo en minutos.
# Tambien esta el algoritmo de Dijkstra con la reconstruccion de la ruta.


def limpiar(texto):
    # Pone el texto en minusculas, sin tildes y sin espacios de mas
    # para que "León", "leon" y "  LEON " cuenten como la misma ciudad
    texto = texto.strip().lower()
    texto = " ".join(texto.split())
    con_tilde = "áéíóúüñ"
    sin_tilde = "aeiouun"
    for i in range(len(con_tilde)):
        texto = texto.replace(con_tilde[i], sin_tilde[i])
    return texto


def formatear_tiempo(minutos):
    # Convierte minutos a texto: 45 min, 2 h, 1 h 15 min
    horas = minutos // 60
    resto = minutos % 60
    if horas == 0:
        return str(resto) + " min"
    if resto == 0:
        return str(horas) + " h"
    return str(horas) + " h " + str(resto) + " min"


class MapaGPS:

    def __init__(self):
        # {ciudad: {ciudad_vecina: minutos}}
        self.rutas = {}

    def buscar_ciudad(self, texto):
        # Devuelve el nombre de la ciudad si existe, si no devuelve None
        texto = limpiar(texto)
        for ciudad in self.rutas:
            if limpiar(ciudad) == texto:
                return ciudad
        return None

    def ver_ciudades(self):
        return sorted(self.rutas.keys(), key=limpiar)

    def ver_rutas(self):
        # Devuelve una lista de (ciudad1, ciudad2, minutos)
        lista = []
        for a in self.ver_ciudades():
            for b in sorted(self.rutas[a].keys(), key=limpiar):
                # asi cada autopista sale una sola vez
                if limpiar(a) < limpiar(b):
                    lista.append((a, b, self.rutas[a][b]))
        return lista

    def agregar_ruta(self, origen, destino, minutos):
        # Agrega una autopista entre dos ciudades (en los dos sentidos).
        # Si una ciudad no existe, la crea.
        # Devuelve el tiempo anterior si la ruta ya existia, si no devuelve None.
        if limpiar(origen) == "" or limpiar(destino) == "":
            raise ValueError("Los nombres de las ciudades no pueden estar vacios")
        if limpiar(origen) == limpiar(destino):
            raise ValueError("El origen y el destino no pueden ser la misma ciudad")
        if type(minutos) != int or minutos <= 0:
            raise ValueError("El tiempo tiene que ser un numero entero mayor que 0")

        a = self.buscar_ciudad(origen)
        if a is None:
            a = " ".join(origen.split()).title()
            self.rutas[a] = {}

        b = self.buscar_ciudad(destino)
        if b is None:
            b = " ".join(destino.split()).title()
            self.rutas[b] = {}

        anterior = None
        if b in self.rutas[a]:
            anterior = self.rutas[a][b]

        self.rutas[a][b] = minutos
        self.rutas[b][a] = minutos
        return anterior

    def tiempo_entre(self, a, b):
        return self.rutas[a][b]

    def ruta_mas_rapida(self, origen, destino):
        # Dijkstra. Devuelve (minutos, camino).
        # Si no hay ninguna ruta devuelve (None, []).
        if limpiar(origen) == "" or limpiar(destino) == "":
            raise ValueError("Tienes que escribir el nombre de las dos ciudades")

        inicio = self.buscar_ciudad(origen)
        fin = self.buscar_ciudad(destino)
        if inicio is None:
            raise ValueError("La ciudad '" + origen.strip() + "' no existe en el mapa")
        if fin is None:
            raise ValueError("La ciudad '" + destino.strip() + "' no existe en el mapa")

        infinito = float("inf")
        tiempos = {}
        anteriores = {}   # de cual ciudad llegue a cada una
        for ciudad in self.rutas:
            tiempos[ciudad] = infinito
            anteriores[ciudad] = None
        tiempos[inicio] = 0

        por_visitar = list(self.rutas.keys())

        while len(por_visitar) > 0:
            # busco la ciudad no visitada con menos tiempo
            actual = por_visitar[0]
            for ciudad in por_visitar:
                if tiempos[ciudad] < tiempos[actual]:
                    actual = ciudad

            # si lo mas cercano es infinito, las que quedan no se alcanzan
            if tiempos[actual] == infinito:
                break

            por_visitar.remove(actual)

            if actual == fin:
                break

            # reviso si pasando por "actual" llego mas rapido a sus vecinas
            for vecina in self.rutas[actual]:
                nuevo = tiempos[actual] + self.rutas[actual][vecina]
                if nuevo < tiempos[vecina]:
                    tiempos[vecina] = nuevo
                    anteriores[vecina] = actual

        if tiempos[fin] == infinito:
            return None, []

        # armo el camino desde el final hacia atras y luego lo volteo
        camino = []
        ciudad = fin
        while ciudad is not None:
            camino.append(ciudad)
            ciudad = anteriores[ciudad]
        camino.reverse()

        return tiempos[fin], camino
