# Tarea 4: Dijkstra que retorna el camino exacto (lista de nodos)
# y no solo la distancia

import heapq


class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])


class GrafoPonderado(Grafo):

    def agregar_arista(self, u, v, peso):
        # Dijkstra no funciona con pesos negativos
        if type(peso) != int and type(peso) != float:
            raise ValueError("El peso tiene que ser un numero")
        if peso != peso or peso == float("inf"):
            raise ValueError("El peso no es un numero valido")
        if peso < 0:
            raise ValueError("El peso no puede ser negativo")

        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append((v, peso))
        if not self.dirigido:
            self.adj[v].append((u, peso))

    # devuelve solo los nombres de los vecinos (sin el peso)
    def vecinos(self, v):
        lista = []
        if v in self.adj:
            for vecino, peso in self.adj[v]:
                lista.append(vecino)
        return lista

    # Dijkstra que devuelve (distancia, camino)
    # Si no hay camino devuelve (None, [])
    def dijkstra_camino(self, inicio, destino):
        if inicio not in self.adj or destino not in self.adj:
            print("Alguno de los vertices no existe en el grafo")
            return None, []

        infinito = float("inf")
        distancias = {}
        anteriores = {}
        for v in self.adj:
            distancias[v] = infinito
            anteriores[v] = None
        distancias[inicio] = 0

        por_visitar = list(self.adj.keys())

        while len(por_visitar) > 0:
            # busco el vertice no visitado con menor distancia
            actual = por_visitar[0]
            for v in por_visitar:
                if distancias[v] < distancias[actual]:
                    actual = v

            # si lo mas cercano es infinito, los que quedan no se alcanzan
            if distancias[actual] == infinito:
                break

            por_visitar.remove(actual)

            if actual == destino:
                break

            for vecino, peso in self.adj[actual]:
                nueva = distancias[actual] + peso
                if nueva < distancias[vecino]:
                    distancias[vecino] = nueva
                    anteriores[vecino] = actual

        if distancias[destino] == infinito:
            return None, []

        # armo el camino desde el destino hacia atras y luego lo volteo
        camino = []
        nodo = destino
        while nodo is not None:
            camino.append(nodo)
            nodo = anteriores[nodo]
        camino.reverse()

        return distancias[destino], camino

    # Dijkstra de la unidad (solo distancias), lo dejo para comparar
    def dijkstra(self, inicio):
        distancias = {}
        for v in self.adj:
            distancias[v] = float("inf")
        distancias[inicio] = 0
        cola = [(0, inicio)]

        while len(cola) > 0:
            dist_actual, actual = heapq.heappop(cola)
            if dist_actual > distancias[actual]:
                continue
            for vecino, peso in self.adj[actual]:
                nueva = dist_actual + peso
                if nueva < distancias[vecino]:
                    distancias[vecino] = nueva
                    heapq.heappush(cola, (nueva, vecino))

        return distancias


gp = GrafoPonderado()
gp.agregar_arista("A", "B", 4)
gp.agregar_arista("A", "C", 2)
gp.agregar_arista("C", "B", 1)
gp.agregar_arista("B", "D", 5)

print("Distancias desde A (solo distancias):", gp.dijkstra("A"))

distancia, camino = gp.dijkstra_camino("A", "D")
print("De A a D:")
print("Distancia:", distancia)
print("Camino:", camino)

distancia, camino = gp.dijkstra_camino("A", "A")
print("De A a A:", distancia, camino)

# un vertice al que no se puede llegar
gp.agregar_vertice("Isla")
distancia, camino = gp.dijkstra_camino("A", "Isla")
print("De A a Isla:", distancia, camino)

# un vertice que no existe
distancia, camino = gp.dijkstra_camino("A", "Z")
print("De A a Z:", distancia, camino)

# grafo dirigido, solo se puede ir en un sentido
gd = GrafoPonderado(dirigido=True)
gd.agregar_arista("P", "Q", 3)
print("Dirigido P a Q:", gd.dijkstra_camino("P", "Q"))
print("Dirigido Q a P:", gd.dijkstra_camino("Q", "P"))

# peso negativo (no se permite)
try:
    gp.agregar_arista("A", "D", -1)
except ValueError as error:
    print("Error:", error)
