# Tarea 3: grafo ponderado de una red de trafico de red
# y camino de menor latencia (los pesos son milisegundos)

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])


class GrafoPonderado(Grafo):

    def agregar_arista(self, u, v, peso):
        # Dijkstra no funciona con pesos negativos
        if type(peso) != int and type(peso) != float:
            raise ValueError("El peso tiene que ser un numero")
        if peso != peso or peso == float("inf"):
            raise ValueError("El peso no es un numero valido")
        if peso < 0:
            raise ValueError("El peso no puede ser negativo")

        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append((v, peso))
        if not self.dirigido:
            self.adj[v].append((u, peso))

    # devuelve solo los nombres de los vecinos (sin el peso)
    def vecinos(self, v):
        lista = []
        if v in self.adj:
            for vecino, peso in self.adj[v]:
                lista.append(vecino)
        return lista

    # Dijkstra que devuelve (distancia, camino)
    # Si no hay camino devuelve (None, [])
    def dijkstra_camino(self, inicio, destino):
        if inicio not in self.adj or destino not in self.adj:
            print("Alguno de los vertices no existe en el grafo")
            return None, []

        infinito = float("inf")
        distancias = {}
        anteriores = {}
        for v in self.adj:
            distancias[v] = infinito
            anteriores[v] = None
        distancias[inicio] = 0

        por_visitar = list(self.adj.keys())

        while len(por_visitar) > 0:
            # busco el vertice no visitado con menor distancia
            actual = por_visitar[0]
            for v in por_visitar:
                if distancias[v] < distancias[actual]:
                    actual = v

            # si lo mas cercano es infinito, los que quedan no se alcanzan
            if distancias[actual] == infinito:
                break

            por_visitar.remove(actual)

            if actual == destino:
                break

            for vecino, peso in self.adj[actual]:
                nueva = distancias[actual] + peso
                if nueva < distancias[vecino]:
                    distancias[vecino] = nueva
                    anteriores[vecino] = actual

        if distancias[destino] == infinito:
            return None, []

        # armo el camino desde el destino hacia atras y luego lo volteo
        camino = []
        nodo = destino
        while nodo is not None:
            camino.append(nodo)
            nodo = anteriores[nodo]
        camino.reverse()

        return distancias[destino], camino


red = GrafoPonderado()
red.agregar_arista("Cliente", "Router1", 5)
red.agregar_arista("Cliente", "Router2", 12)
red.agregar_arista("Router1", "Router2", 4)
red.agregar_arista("Router1", "Switch", 10)
red.agregar_arista("Router2", "Switch", 3)
red.agregar_arista("Router2", "Firewall", 8)
red.agregar_arista("Firewall", "Servidor", 3)
red.agregar_arista("Switch", "Servidor", 7)

print("Red (equipo, latencia en ms):")
red.mostrar()

latencia, ruta = red.dijkstra_camino("Cliente", "Servidor")
print("Menor latencia de Cliente a Servidor:", latencia, "ms")
print("Ruta:", " -> ".join(ruta))

print("Latencia minima desde Cliente a cada equipo:")
for equipo in red.adj:
    distancia, camino = red.dijkstra_camino("Cliente", equipo)
    print(equipo + ":", distancia, "ms")
