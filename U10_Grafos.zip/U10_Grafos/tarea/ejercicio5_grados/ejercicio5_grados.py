# Tarea 5: grado de entrada y de salida de cada nodo en un grafo dirigido

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    # salida = cuantas aristas salen del vertice
    # entrada = cuantas aristas llegan al vertice
    def grados(self):
        entrada = {}
        salida = {}
        for v in self.adj:
            entrada[v] = 0
            salida[v] = 0

        for v in self.adj:
            for vecino in self.vecinos(v):
                salida[v] = salida[v] + 1
                entrada[vecino] = entrada[vecino] + 1

        return entrada, salida

    def mostrar_grados(self):
        entrada, salida = self.grados()
        for v in self.adj:
            print(v, "-> entrada:", entrada[v], "salida:", salida[v])


g = Grafo(dirigido=True)
g.agregar_arista("A", "B")
g.agregar_arista("A", "C")
g.agregar_arista("B", "C")
g.agregar_arista("C", "A")
g.agregar_arista("C", "D")

print("Grafo:")
g.mostrar()

print("Grados:")
g.mostrar_grados()

entrada, salida = g.grados()
print("Entrada:", entrada)
print("Salida:", salida)
