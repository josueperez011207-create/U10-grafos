# grafo.py
# Clase Grafo con lista de adyacencia: un diccionario donde cada vertice
# guarda una lista con sus vecinos.
# Aqui estan los metodos de la unidad y los de la tarea
# (ejercicio 1: dfs_iterativo, ejercicio 2: tiene_ciclo, ejercicio 5: grados)


class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    # DFS recursivo (el de la unidad), lo uso para comparar con el iterativo
    def dfs(self, inicio, visitados=None):
        if visitados is None:
            visitados = []
        visitados.append(inicio)
        for vecino in self.vecinos(inicio):
            if vecino not in visitados:
                self.dfs(vecino, visitados)
        return visitados

    # ---------------------------------------------------------------
    # EJERCICIO 1: DFS iterativo (con una pila en vez de recursividad)
    # ---------------------------------------------------------------
    def dfs_iterativo(self, inicio):
        if inicio not in self.adj:
            print("El vertice", inicio, "no existe en el grafo")
            return []

        visitados = []
        pila = [inicio]

        while len(pila) > 0:
            actual = pila.pop()
            # un vertice puede entrar a la pila dos veces,
            # por eso reviso si ya lo visite
            if actual not in visitados:
                visitados.append(actual)
                vecinos = self.vecinos(actual)
                # los recorro al reves para que el orden salga igual
                # que en el DFS recursivo
                for i in range(len(vecinos) - 1, -1, -1):
                    if vecinos[i] not in visitados:
                        pila.append(vecinos[i])

        return visitados

    # ---------------------------------------------------------------
    # EJERCICIO 2: detectar ciclos en un grafo dirigido
    # Idea: hago DFS y voy guardando el camino actual (en_camino).
    # Si llego a un vertice que ya esta en el camino actual, hay ciclo.
    # ---------------------------------------------------------------
    def tiene_ciclo(self):
        if not self.dirigido:
            print("Este metodo es solo para grafos dirigidos")
            return False

        visitados = []
        # pruebo desde todos los vertices por si el grafo no esta conectado
        for v in self.adj:
            if v not in visitados:
                en_camino = []
                if self.buscar_ciclo(v, visitados, en_camino):
                    return True
        return False

    def buscar_ciclo(self, nodo, visitados, en_camino):
        visitados.append(nodo)
        en_camino.append(nodo)

        for vecino in self.vecinos(nodo):
            if vecino in en_camino:
                return True
            if vecino not in visitados:
                if self.buscar_ciclo(vecino, visitados, en_camino):
                    return True

        # ya revise todos sus vecinos, lo saco del camino actual
        en_camino.remove(nodo)
        return False

    # ---------------------------------------------------------------
    # EJERCICIO 5: grado de entrada y de salida
    # Salida = cuantas aristas salen del vertice
    # Entrada = cuantas aristas llegan al vertice
    # ---------------------------------------------------------------
    def grados(self):
        entrada = {}
        salida = {}
        for v in self.adj:
            entrada[v] = 0
            salida[v] = 0

        for v in self.adj:
            for vecino in self.vecinos(v):
                salida[v] = salida[v] + 1
                entrada[vecino] = entrada[vecino] + 1

        return entrada, salida

    def mostrar_grados(self):
        entrada, salida = self.grados()
        for v in self.adj:
            print(v, "-> entrada:", entrada[v], "| salida:", salida[v])
