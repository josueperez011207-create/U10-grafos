# Tarea 2: detectar si hay ciclos en un grafo dirigido

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    # Hago DFS y voy guardando el camino actual (en_camino).
    # Si llego a un vertice que ya esta en el camino actual, hay ciclo.
    def tiene_ciclo(self):
        if not self.dirigido:
            print("Este metodo es solo para grafos dirigidos")
            return False

        visitados = []
        # pruebo desde todos los vertices por si el grafo no esta conectado
        for v in self.adj:
            if v not in visitados:
                en_camino = []
                if self.buscar_ciclo(v, visitados, en_camino):
                    return True
        return False

    def buscar_ciclo(self, nodo, visitados, en_camino):
        visitados.append(nodo)
        en_camino.append(nodo)

        for vecino in self.vecinos(nodo):
            if vecino in en_camino:
                return True
            if vecino not in visitados:
                if self.buscar_ciclo(vecino, visitados, en_camino):
                    return True

        # ya revise todos sus vecinos, lo saco del camino actual
        en_camino.remove(nodo)
        return False


# grafo sin ciclos
g1 = Grafo(dirigido=True)
g1.agregar_arista("A", "B")
g1.agregar_arista("A", "C")
g1.agregar_arista("B", "D")
g1.agregar_arista("C", "D")
print("Grafo A->B, A->C, B->D, C->D")
print("Tiene ciclo?", g1.tiene_ciclo())

# le agrego D -> A y se forma el ciclo A -> B -> D -> A
g1.agregar_arista("D", "A")
print("Le agrego D->A")
print("Tiene ciclo?", g1.tiene_ciclo())

# grafo vacio
g2 = Grafo(dirigido=True)
print("Grafo vacio")
print("Tiene ciclo?", g2.tiene_ciclo())

# un vertice que apunta a si mismo
g3 = Grafo(dirigido=True)
g3.agregar_arista("X", "X")
print("Grafo con X->X")
print("Tiene ciclo?", g3.tiene_ciclo())

# dos partes separadas, el ciclo esta en la segunda
g4 = Grafo(dirigido=True)
g4.agregar_arista("A", "B")
g4.agregar_arista("M", "N")
g4.agregar_arista("N", "M")
print("Grafo con A->B y M->N, N->M")
print("Tiene ciclo?", g4.tiene_ciclo())

# grafo no dirigido
g5 = Grafo()
g5.agregar_arista("A", "B")
print("Grafo no dirigido")
print("Tiene ciclo?", g5.tiene_ciclo())
