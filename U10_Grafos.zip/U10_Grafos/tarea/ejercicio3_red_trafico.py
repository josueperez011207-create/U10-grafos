# Ejercicio 3: grafo ponderado de una red de trafico de red
# y encontrar el camino de menor latencia
from grafo_ponderado import GrafoPonderado

print("EJERCICIO 3: Red de trafico, camino de menor latencia")
print()

# Los pesos son la latencia en milisegundos (ms)
red = GrafoPonderado()
red.agregar_arista("Cliente", "Router1", 5)
red.agregar_arista("Cliente", "Router2", 12)
red.agregar_arista("Router1", "Router2", 4)
red.agregar_arista("Router1", "Switch", 10)
red.agregar_arista("Router2", "Switch", 3)
red.agregar_arista("Router2", "Firewall", 8)
red.agregar_arista("Firewall", "Servidor", 3)
red.agregar_arista("Switch", "Servidor", 7)

print("Red (vecino, latencia en ms):")
red.mostrar()
print()

latencia, ruta = red.dijkstra_camino("Cliente", "Servidor")
print("Menor latencia de Cliente a Servidor:", latencia, "ms")
print("Ruta:", " -> ".join(ruta))
print()

print("Latencia minima desde Cliente a cada equipo:")
for equipo in red.adj:
    distancia, camino = red.dijkstra_camino("Cliente", equipo)
    print("  ", equipo, ":", distancia, "ms")

# para que la ventana de CMD no se cierre sola si se abre con doble clic
try:
    input("Presiona Enter para cerrar...")
except (EOFError, KeyboardInterrupt):
    pass
