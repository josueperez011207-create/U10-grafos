# Ejercicio 1: escribir un metodo iterativo para DFS
from grafo import Grafo

print("EJERCICIO 1: DFS iterativo")
print()

g = Grafo()
g.agregar_arista("A", "B")
g.agregar_arista("A", "C")
g.agregar_arista("B", "D")
g.agregar_arista("C", "D")
g.agregar_arista("D", "E")

print("Grafo:")
g.mostrar()
print()

print("DFS recursivo:", g.dfs("A"))
print("DFS iterativo:", g.dfs_iterativo("A"))

# un vertice que esta solo
g.agregar_vertice("Z")
print("DFS iterativo desde Z (vertice solo):", g.dfs_iterativo("Z"))

# un vertice que no existe
print("DFS iterativo desde X:", g.dfs_iterativo("X"))

# para que la ventana de CMD no se cierre sola si se abre con doble clic
try:
    input("Presiona Enter para cerrar...")
except (EOFError, KeyboardInterrupt):
    pass
