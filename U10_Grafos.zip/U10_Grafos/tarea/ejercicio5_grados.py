# Ejercicio 5: calcular el grado de entrada y de salida
# de cada nodo en un grafo dirigido
from grafo import Grafo

print("EJERCICIO 5: Grado de entrada y de salida")
print()

g = Grafo(dirigido=True)
g.agregar_arista("A", "B")
g.agregar_arista("A", "C")
g.agregar_arista("B", "C")
g.agregar_arista("C", "A")
g.agregar_arista("C", "D")

print("Grafo:")
g.mostrar()
print()

g.mostrar_grados()
print()

# tambien se puede pedir como diccionarios
entrada, salida = g.grados()
print("Entrada:", entrada)
print("Salida:", salida)

# para que la ventana de CMD no se cierre sola si se abre con doble clic
try:
    input("Presiona Enter para cerrar...")
except (EOFError, KeyboardInterrupt):
    pass
