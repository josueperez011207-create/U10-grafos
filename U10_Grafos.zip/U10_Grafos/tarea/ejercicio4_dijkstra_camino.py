# Ejercicio 4: Dijkstra que devuelve el camino exacto (lista de nodos)
# y no solo la distancia
from grafo_ponderado import GrafoPonderado

print("EJERCICIO 4: Dijkstra con camino exacto")
print()

# Es el grafo del Ejemplo 4 de la unidad
gp = GrafoPonderado()
gp.agregar_arista("A", "B", 4)
gp.agregar_arista("A", "C", 2)
gp.agregar_arista("C", "B", 1)
gp.agregar_arista("B", "D", 5)

distancia, camino = gp.dijkstra_camino("A", "D")
print("De A a D:")
print("  distancia:", distancia)
print("  camino:", camino)

distancia, camino = gp.dijkstra_camino("A", "A")
print("De A a A:", distancia, camino)

# un vertice al que no se puede llegar
gp.agregar_vertice("Isla")
distancia, camino = gp.dijkstra_camino("A", "Isla")
print("De A a Isla:", distancia, camino, "(no hay camino)")

# un vertice que no existe
distancia, camino = gp.dijkstra_camino("A", "Z")
print("De A a Z:", distancia, camino)

# grafo dirigido: solo se puede ir en un sentido
gd = GrafoPonderado(dirigido=True)
gd.agregar_arista("P", "Q", 3)
print("Dirigido P -> Q:", gd.dijkstra_camino("P", "Q"))
print("Dirigido Q -> P:", gd.dijkstra_camino("Q", "P"))

# peso negativo (no se permite)
try:
    gp.agregar_arista("A", "D", -1)
except ValueError as error:
    print("Error:", error)

# para que la ventana de CMD no se cierre sola si se abre con doble clic
try:
    input("Presiona Enter para cerrar...")
except (EOFError, KeyboardInterrupt):
    pass
