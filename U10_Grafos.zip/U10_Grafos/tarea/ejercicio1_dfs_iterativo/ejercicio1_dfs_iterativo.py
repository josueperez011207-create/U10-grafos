# Tarea 1: metodo iterativo para DFS (con una pila en vez de recursividad)

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    def dfs(self, inicio, visitados=None):
        if visitados is None:
            visitados = []
        visitados.append(inicio)
        for vecino in self.vecinos(inicio):
            if vecino not in visitados:
                self.dfs(vecino, visitados)
        return visitados

    def dfs_iterativo(self, inicio):
        if inicio not in self.adj:
            print("El vertice", inicio, "no existe en el grafo")
            return []

        visitados = []
        pila = [inicio]

        while len(pila) > 0:
            actual = pila.pop()
            # un vertice puede entrar a la pila dos veces,
            # por eso reviso si ya lo visite
            if actual not in visitados:
                visitados.append(actual)
                vecinos = self.vecinos(actual)
                # los recorro al reves para que el orden salga igual
                # que en el DFS recursivo
                for i in range(len(vecinos) - 1, -1, -1):
                    if vecinos[i] not in visitados:
                        pila.append(vecinos[i])

        return visitados


g = Grafo()
g.agregar_arista("A", "B")
g.agregar_arista("A", "C")
g.agregar_arista("B", "D")
g.agregar_arista("C", "D")
g.agregar_arista("D", "E")

print("Grafo:")
g.mostrar()

print("DFS recursivo:", g.dfs("A"))
print("DFS iterativo:", g.dfs_iterativo("A"))

# un vertice que esta solo
g.agregar_vertice("Z")
print("DFS iterativo desde Z:", g.dfs_iterativo("Z"))

# un vertice que no existe
print("DFS iterativo desde X:", g.dfs_iterativo("X"))
