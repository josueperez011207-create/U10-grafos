# Ejercicio 2: detectar si hay ciclos en un grafo dirigido
from grafo import Grafo

print("EJERCICIO 2: Detectar ciclos en un grafo dirigido")
print()

# Grafo sin ciclos
g1 = Grafo(dirigido=True)
g1.agregar_arista("A", "B")
g1.agregar_arista("A", "C")
g1.agregar_arista("B", "D")
g1.agregar_arista("C", "D")
print("Grafo 1 (A->B, A->C, B->D, C->D)")
print("  Tiene ciclo?", g1.tiene_ciclo())

# Le agrego D -> A y se forma el ciclo A -> B -> D -> A
g1.agregar_arista("D", "A")
print("Le agrego D->A")
print("  Tiene ciclo?", g1.tiene_ciclo())

# Grafo vacio
g2 = Grafo(dirigido=True)
print("Grafo vacio")
print("  Tiene ciclo?", g2.tiene_ciclo())

# Un vertice que apunta a si mismo
g3 = Grafo(dirigido=True)
g3.agregar_arista("X", "X")
print("Grafo con X->X")
print("  Tiene ciclo?", g3.tiene_ciclo())

# Grafo con dos partes separadas, el ciclo esta en la segunda
g4 = Grafo(dirigido=True)
g4.agregar_arista("A", "B")
g4.agregar_arista("M", "N")
g4.agregar_arista("N", "M")
print("Grafo con dos partes (A->B) y (M->N, N->M)")
print("  Tiene ciclo?", g4.tiene_ciclo())

# Grafo no dirigido (el metodo avisa que es solo para dirigidos)
g5 = Grafo()
g5.agregar_arista("A", "B")
print("Grafo no dirigido")
print("  Tiene ciclo?", g5.tiene_ciclo())

# para que la ventana de CMD no se cierre sola si se abre con doble clic
try:
    input("Presiona Enter para cerrar...")
except (EOFError, KeyboardInterrupt):
    pass
