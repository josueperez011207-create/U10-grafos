# grafo_ponderado.py
# Grafo ponderado: igual que Grafo pero cada arista tiene un peso.
# adj guarda tuplas (vecino, peso).
# Aqui esta el ejercicio 4: Dijkstra que devuelve tambien el camino.

from grafo import Grafo


class GrafoPonderado(Grafo):

    def agregar_arista(self, u, v, peso):
        # Dijkstra no funciona con pesos negativos
        if type(peso) != int and type(peso) != float:
            raise ValueError("El peso tiene que ser un numero")
        if peso != peso or peso == float("inf"):
            raise ValueError("El peso no es un numero valido")
        if peso < 0:
            raise ValueError("El peso no puede ser negativo")

        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append((v, peso))
        if not self.dirigido:
            self.adj[v].append((u, peso))

    # devuelve solo los nombres de los vecinos (sin el peso)
    def vecinos(self, v):
        lista = []
        if v in self.adj:
            for vecino, peso in self.adj[v]:
                lista.append(vecino)
        return lista

    # ---------------------------------------------------------------
    # EJERCICIO 4: Dijkstra con el camino exacto
    # Devuelve (distancia, camino). Si no hay camino devuelve (None, [])
    # ---------------------------------------------------------------
    def dijkstra_camino(self, inicio, destino):
        if inicio not in self.adj or destino not in self.adj:
            print("Alguno de los vertices no existe en el grafo")
            return None, []

        infinito = float("inf")
        distancias = {}
        anteriores = {}   # de cual vertice llegue a cada uno
        for v in self.adj:
            distancias[v] = infinito
            anteriores[v] = None
        distancias[inicio] = 0

        por_visitar = list(self.adj.keys())

        while len(por_visitar) > 0:
            # busco el vertice no visitado con menor distancia
            actual = por_visitar[0]
            for v in por_visitar:
                if distancias[v] < distancias[actual]:
                    actual = v

            # si la menor distancia es infinito, los que quedan no se alcanzan
            if distancias[actual] == infinito:
                break

            por_visitar.remove(actual)

            if actual == destino:
                break

            # reviso si pasando por "actual" llego mas rapido a los vecinos
            for vecino, peso in self.adj[actual]:
                nueva = distancias[actual] + peso
                if nueva < distancias[vecino]:
                    distancias[vecino] = nueva
                    anteriores[vecino] = actual

        if distancias[destino] == infinito:
            return None, []

        # armo el camino desde el destino hacia atras y luego lo volteo
        camino = []
        nodo = destino
        while nodo is not None:
            camino.append(nodo)
            nodo = anteriores[nodo]
        camino.reverse()

        return distancias[destino], camino
