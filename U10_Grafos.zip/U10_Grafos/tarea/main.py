# main.py
# Menu en consola (CMD) para probar los 5 ejercicios de la tarea.
# Para correrlo: python main.py

from grafo import Grafo
from grafo_ponderado import GrafoPonderado


# ------------------------------------------------------------------
# Grafos de ejemplo
# ------------------------------------------------------------------

def ejemplo_dfs():
    g = Grafo()
    g.agregar_arista("A", "B")
    g.agregar_arista("A", "C")
    g.agregar_arista("B", "D")
    g.agregar_arista("C", "D")
    g.agregar_arista("D", "E")
    return g


def ejemplo_sin_ciclos():
    g = Grafo(dirigido=True)
    g.agregar_arista("A", "B")
    g.agregar_arista("A", "C")
    g.agregar_arista("B", "D")
    g.agregar_arista("C", "D")
    return g


def ejemplo_con_ciclo():
    g = Grafo(dirigido=True)
    g.agregar_arista("A", "B")
    g.agregar_arista("B", "C")
    g.agregar_arista("C", "D")
    g.agregar_arista("D", "B")
    return g


def ejemplo_red():
    # los pesos son la latencia en milisegundos
    g = GrafoPonderado()
    g.agregar_arista("Cliente", "Router1", 5)
    g.agregar_arista("Cliente", "Router2", 12)
    g.agregar_arista("Router1", "Router2", 4)
    g.agregar_arista("Router1", "Switch", 10)
    g.agregar_arista("Router2", "Switch", 3)
    g.agregar_arista("Router2", "Firewall", 8)
    g.agregar_arista("Firewall", "Servidor", 3)
    g.agregar_arista("Switch", "Servidor", 7)
    return g


def ejemplo_dijkstra():
    g = GrafoPonderado()
    g.agregar_arista("A", "B", 4)
    g.agregar_arista("A", "C", 2)
    g.agregar_arista("C", "B", 1)
    g.agregar_arista("B", "D", 5)
    return g


def ejemplo_grados():
    g = Grafo(dirigido=True)
    g.agregar_arista("A", "B")
    g.agregar_arista("A", "C")
    g.agregar_arista("B", "C")
    g.agregar_arista("C", "A")
    g.agregar_arista("C", "D")
    return g


# ------------------------------------------------------------------
# Funciones para pedir datos
# ------------------------------------------------------------------

def preguntar_si_no(pregunta):
    respuesta = input(pregunta + " (s/n): ").strip().lower()
    return respuesta == "s" or respuesta == "si"


def pedir_aristas(g, ponderado):
    print()
    print("Escribe las aristas, una por linea.")
    if ponderado:
        print("Formato: origen destino peso   (ejemplo: A B 5)")
    else:
        print("Formato: origen destino   (ejemplo: A B)")
    print("Cuando termines, deja la linea vacia y presiona Enter.")

    while True:
        linea = input("> ").strip()
        if linea == "":
            break

        partes = linea.split()

        if ponderado:
            if len(partes) != 3:
                print("Formato incorrecto, tiene que ser: origen destino peso")
                continue
            # el peso puede ser entero o decimal
            try:
                peso = int(partes[2])
            except ValueError:
                try:
                    peso = float(partes[2])
                except ValueError:
                    print("El peso tiene que ser un numero")
                    continue
            try:
                g.agregar_arista(partes[0], partes[1], peso)
            except ValueError as error:
                print("Error:", error)
        else:
            if len(partes) != 2:
                print("Formato incorrecto, tiene que ser: origen destino")
                continue
            g.agregar_arista(partes[0], partes[1])


def elegir_grafo(ponderado, dirigido, ejemplos):
    # ejemplos es una lista de (nombre, funcion que crea el grafo)
    # dirigido = None significa que se le pregunta al usuario
    print()
    print("De donde sacamos el grafo?")
    numero = 1
    for nombre, funcion in ejemplos:
        print(str(numero) + ". " + nombre)
        numero = numero + 1
    print(str(numero) + ". Ingresar mi propio grafo")

    opcion = input("Elige: ").strip()
    try:
        n = int(opcion)
    except ValueError:
        n = 0

    if n >= 1 and n <= len(ejemplos):
        g = ejemplos[n - 1][1]()
    elif n == numero:
        if dirigido is None:
            dirigido = preguntar_si_no("El grafo es dirigido?")
        if ponderado:
            g = GrafoPonderado(dirigido)
        else:
            g = Grafo(dirigido)
        pedir_aristas(g, ponderado)
    else:
        print("Opcion no valida")
        return None

    if len(g.adj) == 0:
        print("El grafo quedo vacio, no hay nada que calcular.")
        return None

    print()
    print("Tu grafo:")
    g.mostrar()
    return g


def pedir_vertice(g, texto):
    vertice = input(texto).strip()
    if vertice not in g.adj:
        print("Error: el vertice '" + vertice + "' no existe en el grafo")
        print("(ojo: las mayusculas y minusculas cuentan)")
        return None
    return vertice


# ------------------------------------------------------------------
# Ejercicios
# ------------------------------------------------------------------

def ejercicio1():
    print()
    print("--- EJERCICIO 1: DFS iterativo ---")
    g = elegir_grafo(False, None,
                     [("Grafo de ejemplo (A-B, A-C, B-D, C-D, D-E)", ejemplo_dfs)])
    if g is None:
        return

    print()
    print("Vertices: " + ", ".join(g.adj.keys()))
    inicio = pedir_vertice(g, "Vertice de inicio: ")
    if inicio is None:
        return

    print()
    print("DFS recursivo:", g.dfs(inicio))
    print("DFS iterativo:", g.dfs_iterativo(inicio))


def ejercicio2():
    print()
    print("--- EJERCICIO 2: Detectar ciclos (grafo dirigido) ---")
    g = elegir_grafo(False, True,
                     [("Ejemplo sin ciclos (A->B, A->C, B->D, C->D)", ejemplo_sin_ciclos),
                      ("Ejemplo con ciclo (A->B, B->C, C->D, D->B)", ejemplo_con_ciclo)])
    if g is None:
        return

    print()
    if g.tiene_ciclo():
        print("Resultado: el grafo SI tiene ciclos")
    else:
        print("Resultado: el grafo NO tiene ciclos")


def consultar_camino(g, unidad, mostrar_todos):
    print()
    print("Vertices: " + ", ".join(g.adj.keys()))
    inicio = pedir_vertice(g, "Vertice de inicio: ")
    if inicio is None:
        return
    destino = pedir_vertice(g, "Vertice de destino: ")
    if destino is None:
        return

    distancia, camino = g.dijkstra_camino(inicio, destino)

    print()
    if distancia is None:
        print("No hay ningun camino de " + inicio + " a " + destino)
    else:
        print("Camino mas corto: " + " -> ".join(camino))
        total = str(distancia)
        if unidad != "":
            total = total + " " + unidad
        print("Total: " + total)

    if mostrar_todos:
        print()
        print("Desde " + inicio + " a cada vertice:")
        for v in g.adj:
            d, c = g.dijkstra_camino(inicio, v)
            if d is None:
                print("  " + v + ": no se puede llegar")
            else:
                print("  " + v + ": " + str(d) + " " + unidad)


def ejercicio3():
    print()
    print("--- EJERCICIO 3: Red de trafico (menor latencia) ---")
    print("Los pesos son la latencia en milisegundos (ms)")
    g = elegir_grafo(True, False,
                     [("Red de ejemplo (Cliente, Routers, Switch, Firewall, Servidor)", ejemplo_red)])
    if g is None:
        return
    consultar_camino(g, "ms", True)


def ejercicio4():
    print()
    print("--- EJERCICIO 4: Dijkstra con el camino exacto ---")
    g = elegir_grafo(True, None,
                     [("Grafo de ejemplo (A-B 4, A-C 2, C-B 1, B-D 5)", ejemplo_dijkstra)])
    if g is None:
        return
    consultar_camino(g, "", False)


def ejercicio5():
    print()
    print("--- EJERCICIO 5: Grado de entrada y de salida ---")
    g = elegir_grafo(False, True,
                     [("Grafo de ejemplo (A->B, A->C, B->C, C->A, C->D)", ejemplo_grados)])
    if g is None:
        return

    print()
    g.mostrar_grados()


# ------------------------------------------------------------------
# Menu
# ------------------------------------------------------------------

def mostrar_menu():
    print()
    print("=" * 45)
    print("   UNIDAD 10: GRAFOS - TAREA")
    print("=" * 45)
    print("1. DFS iterativo")
    print("2. Detectar ciclos en un grafo dirigido")
    print("3. Red de trafico (menor latencia)")
    print("4. Dijkstra con camino exacto")
    print("5. Grado de entrada y de salida")
    print("6. Salir")


def main():
    while True:
        mostrar_menu()
        try:
            opcion = input("Elige una opcion: ").strip()

            if opcion == "1":
                ejercicio1()
            elif opcion == "2":
                ejercicio2()
            elif opcion == "3":
                ejercicio3()
            elif opcion == "4":
                ejercicio4()
            elif opcion == "5":
                ejercicio5()
            elif opcion == "6":
                print("Chao!")
                break
            else:
                print("Opcion no valida, escribe un numero del 1 al 6.")

        except (EOFError, KeyboardInterrupt):
            # por si se cierra la entrada o se presiona Ctrl+C
            print()
            print("Saliendo del programa...")
            break
        except Exception as error:
            # para que el programa no se cierre por un error inesperado
            print("Ocurrio un error inesperado:", error)


main()

# para que la ventana de CMD no se cierre sola si se abre con doble clic
try:
    input("Presiona Enter para cerrar...")
except (EOFError, KeyboardInterrupt):
    pass
