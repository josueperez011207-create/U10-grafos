from collections import deque


class Grafo:
    def __init__(self, dirigido=False):
        """Inicializa un grafo con una lista de adyacencia (diccionario)."""
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        """Agrega un vértice al grafo."""
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        """Agrega una arista entre u y v."""
        self.agregar_vertice(u)
        self.agregar_vertice(v)

        self.adj[u].append(v)
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        """Retorna los vecinos de un vértice."""
        return self.adj.get(v, [])

    def bfs(self, inicio):
        """Recorrido en Anchura."""
        visitados = set()
        cola = deque([inicio])
        resultado = []

        visitados.add(inicio)

        while cola:
            actual = cola.popleft()
            resultado.append(actual)

            for vecino in self.vecinos(actual):
                if vecino not in visitados:
                    visitados.add(vecino)
                    cola.append(vecino)

        return resultado

    def dfs(self, inicio, visitados=None, resultado=None):
        """Recorrido en Profundidad (Recursivo)."""
        if visitados is None:
            visitados = set()
            resultado = []

        visitados.add(inicio)
        resultado.append(inicio)

        for vecino in self.vecinos(inicio):
            if vecino not in visitados:
                self.dfs(vecino, visitados, resultado)

        return resultado

    def mostrar(self):
        """Muestra el grafo."""
        for v, vecinos in self.adj.items():
            print(f"{v} -> {vecinos}")


class GrafoPonderado(Grafo):
    def __init__(self, dirigido=False):
        super().__init__(dirigido)
        # adj será un dict donde la clave es el vértice y el valor es una lista de tuplas (vecino, peso)

    def agregar_arista(self, u, v, peso):
        self.agregar_vertice(u)
        self.agregar_vertice(v)

        self.adj[u].append((v, peso))
        if not self.dirigido:
            self.adj[v].append((u, peso))

    def vecinos(self, v):
        """Retorna los vecinos de un vértice sin el peso para compatibilidad."""
        return [vecino for vecino, peso in self.adj.get(v, [])]

    def dijkstra(self, inicio):
        """
        Calcula el camino más corto desde 'inicio' a todos los demás vértices.
        """
        import heapq
        distancias = {v: float('infinity') for v in self.adj}
        distancias[inicio] = 0
        pq = [(0, inicio)] # (distancia, vertice)

        while pq:
            dist_actual, actual = heapq.heappop(pq)

            if dist_actual > distancias[actual]:
                continue

            for vecino, peso in self.adj.get(actual, []):
                distancia = dist_actual + peso

                if distancia < distancias[vecino]:
                    distancias[vecino] = distancia
                    heapq.heappush(pq, (distancia, vecino))

        return distancias


# Ejemplo 3: BFS para encontrar conectados
g = Grafo()
g.agregar_arista('Alice', 'Bob')
g.agregar_arista('Alice', 'Charlie')
g.agregar_arista('Bob', 'David')
g.agregar_arista('Charlie', 'Eve')
g.agregar_arista('Eve', 'Frank')
# Gina y Hugo no estan conectados con Alice
g.agregar_arista('Gina', 'Hugo')

print("Orden BFS:", g.bfs('Alice'))
