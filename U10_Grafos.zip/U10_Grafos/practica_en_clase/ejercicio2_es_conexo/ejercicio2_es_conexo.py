# Practica 2: metodo es_conexo() que usa BFS

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    def bfs(self, inicio):
        visitados = [inicio]
        cola = [inicio]
        resultado = []
        while len(cola) > 0:
            actual = cola.pop(0)
            resultado.append(actual)
            for vecino in self.vecinos(actual):
                if vecino not in visitados:
                    visitados.append(vecino)
                    cola.append(vecino)
        return resultado

    # Un grafo es conexo si desde un vertice con BFS se llega a todos
    def es_conexo(self):
        if len(self.adj) == 0:
            return True

        grafo = self
        # si es dirigido no importa la direccion, hago una copia no dirigida
        if self.dirigido:
            grafo = Grafo()
            for v in self.adj:
                grafo.agregar_vertice(v)
            for u in self.adj:
                for w in self.vecinos(u):
                    grafo.agregar_arista(u, w)

        primero = list(grafo.adj.keys())[0]
        alcanzados = grafo.bfs(primero)
        return len(alcanzados) == len(grafo.adj)


g1 = Grafo()
g1.agregar_arista("A", "B")
g1.agregar_arista("B", "C")
g1.agregar_arista("C", "D")
print("Grafo A-B, B-C, C-D es conexo?", g1.es_conexo())

g2 = Grafo()
g2.agregar_arista("A", "B")
g2.agregar_arista("C", "D")
print("Grafo A-B, C-D es conexo?", g2.es_conexo())

g3 = Grafo()
g3.agregar_arista("A", "B")
g3.agregar_vertice("Z")
print("Grafo A-B con Z solo es conexo?", g3.es_conexo())

g4 = Grafo(dirigido=True)
g4.agregar_arista("A", "B")
g4.agregar_arista("C", "B")
print("Grafo dirigido A->B, C->B es conexo?", g4.es_conexo())

g5 = Grafo()
print("Grafo vacio es conexo?", g5.es_conexo())
