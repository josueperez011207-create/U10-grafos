# Practica 3: ruta mas corta (en saltos) usando BFS

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    # Devuelve la lista de vertices del camino con menos saltos
    # Si no hay camino devuelve una lista vacia
    def ruta_mas_corta(self, inicio, destino):
        if inicio not in self.adj or destino not in self.adj:
            print("Alguno de los vertices no existe")
            return []

        anteriores = {inicio: None}
        cola = [inicio]

        while len(cola) > 0:
            actual = cola.pop(0)
            if actual == destino:
                break
            for vecino in self.vecinos(actual):
                if vecino not in anteriores:
                    anteriores[vecino] = actual
                    cola.append(vecino)

        if destino not in anteriores:
            return []

        camino = []
        nodo = destino
        while nodo is not None:
            camino.append(nodo)
            nodo = anteriores[nodo]
        camino.reverse()
        return camino


g = Grafo()
g.agregar_arista("Managua", "Masaya")
g.agregar_arista("Masaya", "Granada")
g.agregar_arista("Granada", "Rivas")
g.agregar_arista("Managua", "Leon")
g.agregar_arista("Leon", "Chinandega")
g.agregar_vertice("Bilwi")

g.mostrar()

camino = g.ruta_mas_corta("Managua", "Rivas")
print("Managua a Rivas:", camino, "- saltos:", len(camino) - 1)

camino = g.ruta_mas_corta("Chinandega", "Granada")
print("Chinandega a Granada:", camino, "- saltos:", len(camino) - 1)

camino = g.ruta_mas_corta("Managua", "Managua")
print("Managua a Managua:", camino, "- saltos:", len(camino) - 1)

print("Managua a Bilwi:", g.ruta_mas_corta("Managua", "Bilwi"))
