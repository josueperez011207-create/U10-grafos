# Practica 1: grafo que representa un arbol genealogico
# Es dirigido: cada flecha va del padre/madre hacia el hijo/a

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])

    def dfs(self, inicio, visitados=None):
        if visitados is None:
            visitados = []
        visitados.append(inicio)
        for vecino in self.vecinos(inicio):
            if vecino not in visitados:
                self.dfs(vecino, visitados)
        return visitados

    # busca quienes son los padres de una persona
    def padres(self, persona):
        lista = []
        for v in self.adj:
            if persona in self.adj[v]:
                lista.append(v)
        return lista


arbol = Grafo(dirigido=True)
arbol.agregar_arista("Jose", "Carlos")
arbol.agregar_arista("Jose", "Marta")
arbol.agregar_arista("Carlos", "Luis")
arbol.agregar_arista("Carlos", "Ana")
arbol.agregar_arista("Marta", "Pedro")
arbol.agregar_arista("Luis", "Sofia")

print("Arbol genealogico (persona -> hijos):")
arbol.mostrar()

print("Hijos de Carlos:", arbol.vecinos("Carlos"))
print("Padres de Sofia:", arbol.padres("Sofia"))

descendientes = arbol.dfs("Jose")
descendientes.remove("Jose")
print("Descendientes de Jose:", descendientes)
