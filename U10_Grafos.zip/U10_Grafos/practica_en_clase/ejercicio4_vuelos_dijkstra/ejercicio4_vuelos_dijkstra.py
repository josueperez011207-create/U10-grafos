# Practica 4: sistema de vuelos con costos, Dijkstra para viajar barato

class Grafo:

    def __init__(self, dirigido=False):
        self.adj = {}
        self.dirigido = dirigido

    def agregar_vertice(self, v):
        if v not in self.adj:
            self.adj[v] = []

    def agregar_arista(self, u, v):
        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append(v)
        # si no es dirigido la arista va en los dos sentidos
        if not self.dirigido:
            self.adj[v].append(u)

    def vecinos(self, v):
        if v in self.adj:
            return self.adj[v]
        return []

    def mostrar(self):
        for v in self.adj:
            print(v, "->", self.adj[v])


class GrafoPonderado(Grafo):

    def agregar_arista(self, u, v, peso):
        # Dijkstra no funciona con pesos negativos
        if type(peso) != int and type(peso) != float:
            raise ValueError("El peso tiene que ser un numero")
        if peso != peso or peso == float("inf"):
            raise ValueError("El peso no es un numero valido")
        if peso < 0:
            raise ValueError("El peso no puede ser negativo")

        self.agregar_vertice(u)
        self.agregar_vertice(v)
        self.adj[u].append((v, peso))
        if not self.dirigido:
            self.adj[v].append((u, peso))

    # devuelve solo los nombres de los vecinos (sin el peso)
    def vecinos(self, v):
        lista = []
        if v in self.adj:
            for vecino, peso in self.adj[v]:
                lista.append(vecino)
        return lista

    # Dijkstra que devuelve (distancia, camino)
    # Si no hay camino devuelve (None, [])
    def dijkstra_camino(self, inicio, destino):
        if inicio not in self.adj or destino not in self.adj:
            print("Alguno de los vertices no existe en el grafo")
            return None, []

        infinito = float("inf")
        distancias = {}
        anteriores = {}
        for v in self.adj:
            distancias[v] = infinito
            anteriores[v] = None
        distancias[inicio] = 0

        por_visitar = list(self.adj.keys())

        while len(por_visitar) > 0:
            # busco el vertice no visitado con menor distancia
            actual = por_visitar[0]
            for v in por_visitar:
                if distancias[v] < distancias[actual]:
                    actual = v

            # si lo mas cercano es infinito, los que quedan no se alcanzan
            if distancias[actual] == infinito:
                break

            por_visitar.remove(actual)

            if actual == destino:
                break

            for vecino, peso in self.adj[actual]:
                nueva = distancias[actual] + peso
                if nueva < distancias[vecino]:
                    distancias[vecino] = nueva
                    anteriores[vecino] = actual

        if distancias[destino] == infinito:
            return None, []

        # armo el camino desde el destino hacia atras y luego lo volteo
        camino = []
        nodo = destino
        while nodo is not None:
            camino.append(nodo)
            nodo = anteriores[nodo]
        camino.reverse()

        return distancias[destino], camino


vuelos = GrafoPonderado()
vuelos.agregar_arista("Managua", "San Salvador", 120)
vuelos.agregar_arista("Managua", "Panama", 250)
vuelos.agregar_arista("Managua", "Miami", 650)
vuelos.agregar_arista("San Salvador", "Mexico", 200)
vuelos.agregar_arista("Mexico", "Miami", 260)
vuelos.agregar_arista("Panama", "Miami", 300)
vuelos.agregar_arista("Panama", "Bogota", 180)
vuelos.agregar_arista("Bogota", "Madrid", 600)
vuelos.agregar_arista("Miami", "Madrid", 520)
vuelos.agregar_arista("Mexico", "Madrid", 640)
vuelos.agregar_vertice("Lima")

print("Vuelos disponibles (destino, costo en dolares):")
vuelos.mostrar()
print()

for destino in ["San Salvador", "Miami", "Bogota", "Madrid", "Lima"]:
    costo, ruta = vuelos.dijkstra_camino("Managua", destino)
    if costo is None:
        print("Managua a", destino + ": no hay vuelos")
    else:
        print("Managua a", destino + ": $" + str(costo), "-", " -> ".join(ruta))
